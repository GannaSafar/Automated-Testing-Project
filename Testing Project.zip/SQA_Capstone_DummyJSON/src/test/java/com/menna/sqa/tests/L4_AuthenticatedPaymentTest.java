package com.menna.sqa.tests;

import com.menna.sqa.base.BaseApiTest;
import io.restassured.response.Response;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class L4_AuthenticatedPaymentTest extends BaseApiTest {
    private static String token;

    @Test(priority = 1, description = "L4 Step 1: Authenticate and store bearer token")
    public void authenticate_shouldReturnToken() {
        JSONObject credentials = new JSONObject();
        credentials.put("username", "emilys");
        credentials.put("password", "emilyspass");
        credentials.put("expiresInMins", 30);

        Response response = given()
            .contentType("application/json")
            .body(credentials.toJSONString())
        .when()
            .post("/auth/login")
        .then()
            .log().all()
            .statusCode(200)
            .contentType(containsString("application/json"))
            .body("accessToken", notNullValue())
            .time(lessThan(3000L))
            .extract().response();

        token = response.jsonPath().getString("accessToken");
        Assert.assertNotNull(token, "Access token should be stored for the next request");
    }

    @Test(priority = 2, dependsOnMethods = "authenticate_shouldReturnToken", description = "L4 Step 2: Simulate authenticated payment as a cart checkout")
    public void sendPayment_shouldReturnTransactionId() {
        JSONObject product = new JSONObject();
        product.put("id", 1);
        product.put("quantity", 1);

        JSONArray products = new JSONArray();
        products.add(product);

        JSONObject paymentBody = new JSONObject();
        paymentBody.put("userId", 1);
        paymentBody.put("products", products);

        given()
            .header("Authorization", "Bearer " + token)
            .contentType("application/json")
            .body(paymentBody.toJSONString())
        .when()
            .post("/carts/add")
        .then()
            .log().all()
            .statusCode(anyOf(is(200), is(201)))
            .contentType(containsString("application/json"))
            .body("id", notNullValue())
            .body("userId", equalTo(1))
            .body("products[0].id", equalTo(1))
            .time(lessThan(5000L));
    }
}
