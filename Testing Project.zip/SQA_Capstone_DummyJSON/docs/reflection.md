# Real-World Reflection — API Quality Assurance Capstone

This project implements a five-level API regression suite using REST-Assured, TestNG, and DummyJSON. The goal is to simulate how real companies validate critical API flows before deployment.

## Level 1 — E-Commerce Catalog

The first level tests a product catalog endpoint using `GET /products`. This maps to companies such as Amazon, Shopify, Jumia, and Noon, where the catalog must load correctly before users can browse products or start checkout. The test validates status code, JSON content type, product ID, product title, and response time.

## Level 2 — Service Ticket Portal

The second level simulates filing a service complaint using `POST /posts/add`. This reflects platforms such as ServiceNow, Salesforce Service Cloud, Gov.uk, and Digital Egypt. A service portal must confirm that a submitted request is accepted and receives a server-generated ID. The test validates the returned title, user ID, generated ID, JSON content type, and SLA.

## Level 3 — Mobile Banking Customer Update

The third level simulates updating customer profile data using `PUT /users/2`. This maps to mobile banking applications such as Revolut, HSBC, Chase, CIB, and other Open Banking/PSD2-style systems. In banking, profile update APIs must be reliable because incorrect customer data can cause compliance and operational risks. The test validates status code, returned customer ID, updated fields, JSON content type, and response time.

## Level 4 — Authenticated Payment Flow

The fourth level uses a two-step flow: first, login through `POST /auth/login`, then send an authenticated request with a Bearer token. This reflects payment platforms such as PayPal, Apple Pay, M-Pesa, InstaPay, and Fawry. Modern payment systems depend on secure authentication before any money movement or checkout action. The test verifies that the token is returned, stored, and reused in the Authorization header.

## Level 5 — End-to-End Checkout and Refund

The fifth level chains multiple API calls together: customer authentication, product browsing, adding to cart, payment simulation, and refund/delete simulation. This represents the nightly regression style used by e-commerce and payment companies before production releases. The important QA idea is that IDs and data must pass correctly between steps, and every step must validate both status code and response body. DummyJSON simulates create/update/delete behavior, so the final DELETE step uses a stable existing resource while still checking that the transaction flow was created and chained.

## Conclusion

Overall, this suite demonstrates API test planning, CRUD validation, authentication, response body assertions, SLA timing checks, TestNG priorities, dependency between tests, and maintainable code through a shared base class. These are the same core ideas used in real-world regression testing pipelines.
