package com.menna.sqa.tests;

import com.menna.sqa.base.BaseApiTest;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class L3_UpdateBankCustomerTest extends BaseApiTest {

    @Test(description = "L3: Update customer profile using DummyJSON users")
    public void updateCustomer_shouldReturnUpdatedProfile() {
        JSONObject body = new JSONObject();
        body.put("firstName", "Khaled");
        body.put("role", "VIP Customer");

        given()
            .contentType("application/json")
            .body(body.toJSONString())
        .when()
            .put("/users/2")
        .then()
            .log().all()
            .statusCode(200)
            .contentType(containsString("application/json"))
            .body("id", equalTo(2))
            .body("firstName", equalTo("Khaled"))
            .body("role", equalTo("VIP Customer"))
            .time(lessThan(3000L));
    }
}
