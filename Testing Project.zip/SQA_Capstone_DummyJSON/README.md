# SQA Capstone Lab — DummyJSON API Testing Project

This Maven/TestNG/REST-Assured project implements the 5 required API testing levels using DummyJSON instead of the unstable APIs from the original handout.

## What is included

- `L1_GetCatalogTest` — GET product catalog
- `L2_FileServiceTicketTest` — POST service ticket using posts/add
- `L3_UpdateBankCustomerTest` — PUT user/customer update
- `L4_AuthenticatedPaymentTest` — login + authenticated checkout/payment simulation
- `L5_EndToEndCheckoutRefundTest` — chained end-to-end flow: login, browse product, add cart, pay, refund/delete
- `BaseApiTest` — shared base URL and relaxed HTTPS validation
- `testng.xml` — runs all five levels together
- `docs/reflection.md` — one-page reflection mapping levels to real companies

## How to run

From the project root:

```bash
mvn -q -DskipTests compile
mvn clean test
```

Run one class only:

```bash
mvn -Dtest=L1_GetCatalogTest test
```

## Report location

After running:

```text
target/surefire-reports/index.html
```

Take a screenshot of the green TestNG result for submission.

## Important note about DummyJSON

DummyJSON simulates create/update/delete operations. New resources are returned in the response but are not permanently saved on the server. Because of this, the final refund/delete step uses a real existing post ID for DELETE while still checking that the transaction ID was created and passed correctly inside the test flow.
