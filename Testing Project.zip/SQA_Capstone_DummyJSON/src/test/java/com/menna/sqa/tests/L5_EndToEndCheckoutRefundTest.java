package com.menna.sqa.tests;

import com.menna.sqa.base.BaseApiTest;
import io.restassured.response.Response;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class L5_EndToEndCheckoutRefundTest extends BaseApiTest {
    private static Integer userId;
    private static String token;
    private static Integer productId;
    private static Float productPrice;
    private static Integer cartId;
    private static Integer txnId;

    @Test(priority = 1, description = "L5 Step 1: Register/Login customer and capture userId + token")
    public void registerCustomer() {
        JSONObject credentials = new JSONObject();
        credentials.put("username", "emilys");
        credentials.put("password", "emilyspass");
        credentials.put("expiresInMins", 30);

        Response response = given()
            .contentType("application/json")
            .body(credentials.toJSONString())
        .when()
            .post("/auth/login")
        .then()
            .log().all()
            .statusCode(200)
            .contentType(containsString("application/json"))
            .body("id", notNullValue())
            .body("accessToken", notNullValue())
            .time(lessThan(3000L))
            .extract().response();

        userId = response.jsonPath().getInt("id");
        token = response.jsonPath().getString("accessToken");
        Assert.assertNotNull(userId);
        Assert.assertNotNull(token);
    }

    @Test(priority = 2, dependsOnMethods = "registerCustomer", description = "L5 Step 2: Browse catalog and capture productId + price")
    public void browseCatalog() {
        Response response = given()
        .when()
            .get("/products/1")
        .then()
            .log().all()
            .statusCode(200)
            .contentType(containsString("application/json"))
            .body("id", equalTo(1))
            .body("price", notNullValue())
            .time(lessThan(3000L))
            .extract().response();

        productId = response.jsonPath().getInt("id");
        productPrice = response.jsonPath().getFloat("price");
        Assert.assertTrue(productPrice > 0);
    }

    @Test(priority = 3, dependsOnMethods = "browseCatalog", description = "L5 Step 3: Add selected product to cart and capture cartId")
    public void addToCart() {
        JSONObject product = new JSONObject();
        product.put("id", productId);
        product.put("quantity", 1);

        JSONArray products = new JSONArray();
        products.add(product);

        JSONObject cartBody = new JSONObject();
        cartBody.put("userId", userId);
        cartBody.put("products", products);

        Response response = given()
            .contentType("application/json")
            .body(cartBody.toJSONString())
        .when()
            .post("/carts/add")
        .then()
            .log().all()
            .statusCode(anyOf(is(200), is(201)))
            .contentType(containsString("application/json"))
            .body("id", notNullValue())
            .body("products[0].id", equalTo(productId))
            .time(lessThan(3000L))
            .extract().response();

        cartId = response.jsonPath().getInt("id");
        Assert.assertNotNull(cartId);
    }

    @Test(priority = 4, dependsOnMethods = "addToCart", description = "L5 Step 4: Pay for cart using bearer token and capture transaction id")
    public void payForCart() {
        JSONObject payment = new JSONObject();
        payment.put("title", "Payment for cart " + cartId);
        payment.put("body", "Paid EGP " + productPrice + " for product " + productId);
        payment.put("userId", userId);

        Response response = given()
            .header("Authorization", "Bearer " + token)
            .contentType("application/json")
            .body(payment.toJSONString())
        .when()
            .post("/posts/add")
        .then()
            .log().all()
            .statusCode(anyOf(is(200), is(201)))
            .contentType(containsString("application/json"))
            .body("id", notNullValue())
            .body("title", containsString("Payment for cart"))
            .time(lessThan(3000L))
            .extract().response();

        txnId = response.jsonPath().getInt("id");
        Assert.assertNotNull(txnId);
    }

    @Test(priority = 5, dependsOnMethods = "payForCart", description = "L5 Step 5: Refund transaction using DELETE simulation")
    public void refundTxn() {
        // DummyJSON add endpoints simulate creation and do not persist new IDs.
        // To keep the DELETE step green and meaningful, we delete an existing post while still proving txnId was chained.
        Assert.assertNotNull(txnId, "Payment transaction id must be captured before refund");

        given()
        .when()
            .delete("/posts/1")
        .then()
            .log().all()
            .statusCode(200)
            .contentType(containsString("application/json"))
            .body("id", equalTo(1))
            .body("isDeleted", equalTo(true))
            .body("deletedOn", notNullValue())
            .time(lessThan(3000L));
    }
}
