package com.menna.sqa.tests;

import com.menna.sqa.base.BaseApiTest;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class L1_GetCatalogTest extends BaseApiTest {

    @Test(description = "L1: Fetch product catalog from DummyJSON")
    public void getCatalog_shouldReturnJsonProducts() {
        given()
        .when()
            .get("/products")
        .then()
            .log().all()
            .statusCode(200)
            .contentType(containsString("application/json"))
            .body("products[0].id", equalTo(1))
            .body("products[0].title", notNullValue())
            .time(lessThan(3000L));
    }
}
