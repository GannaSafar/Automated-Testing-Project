package com.menna.sqa.tests;

import com.menna.sqa.base.BaseApiTest;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class L2_FileServiceTicketTest extends BaseApiTest {

    @Test(description = "L2: File a service ticket using DummyJSON posts")
    public void createServiceTicket_shouldReturnCreatedTicket() {
        JSONObject body = new JSONObject();
        body.put("title", "Power outage in Zone 4");
        body.put("body", "No electricity since 18:00.");
        body.put("userId", 7);

        given()
            .contentType("application/json")
            .body(body.toJSONString())
        .when()
            .post("/posts/add")
        .then()
            .log().all()
            .statusCode(anyOf(is(200), is(201)))
            .contentType(containsString("application/json"))
            .body("title", equalTo("Power outage in Zone 4"))
            .body("userId", equalTo(7))
            .body("id", notNullValue())
            .time(lessThan(3000L));
    }
}
